package com.db.dataplatform.techtest.server.component;

import java.io.IOException;

public interface ServerHadoop {
	
	void pushToHadoop() throws IOException ;

}
