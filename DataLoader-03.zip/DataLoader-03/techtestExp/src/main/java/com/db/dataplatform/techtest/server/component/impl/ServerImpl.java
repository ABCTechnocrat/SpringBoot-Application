package com.db.dataplatform.techtest.server.component.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.constraints.NotNull;
import javax.xml.bind.DatatypeConverter;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.db.dataplatform.techtest.server.api.model.DataBody;
import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.api.model.DataHeader;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataBodyEntity;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.service.DataBodyService;
import com.db.dataplatform.techtest.server.service.DataHeaderService;

@Slf4j
@Service
@RequiredArgsConstructor
public class ServerImpl implements Server {
	
	private final DataHeaderService dataHeaderServiceImpl;
	private final DataBodyService dataBodyServiceImpl;
	private final ModelMapper modelMapper;

	// ========================================================================================================================
	// ========================================================================================================================
	// PERSIST
	// ========================================================================================================================
	// ========================================================================================================================
	/**
	 * @param envelope
	 * @return true if there is a match with the client provided checksum.
	 */
	@Override
	public boolean saveDataEnvelope(DataEnvelope envelope) {

		// Save to persistence.
		persist(envelope);
		log.info("Data persisted successfully, data name: {}", envelope.getDataHeader().getName());
		return true;
	}

	private void persist(DataEnvelope envelope) {
	
		DataHeaderEntity dataHeaderEntity = modelMapper.map(envelope.getDataHeader(), DataHeaderEntity.class);
		DataBodyEntity dataBodyEntity = new DataBodyEntity();
		dataBodyEntity.setDatachecksum(envelope.getDataBody().getDataChecksum());
		dataBodyEntity.setDataHeaderEntity(dataHeaderEntity);
		log.info("2 Pushing data {} to {}", dataBodyEntity.getDataBody());
		log.info("2 Pushing data {} to {}", dataBodyEntity.getDataHeaderEntity().getName());
		log.info("2 Pushing data {} to {}", dataBodyEntity.getDataHeaderEntity().getBlocktype());

		saveData(dataBodyEntity);
		
	}

	private void saveData(DataBodyEntity dataBodyEntity) {
		dataBodyServiceImpl.saveDataBody(dataBodyEntity);
	}

	
	@Override
	public boolean checksumeValidity(DataEnvelope dataEnvelope) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(dataEnvelope.getDataBody().getDatabody().getBytes());
		byte[] digest = md.digest();
		String appHash = DatatypeConverter.printHexBinary(digest).toUpperCase();
		log.info("AppHash calculated is : {}", appHash);		
		boolean checksumPass = false;
		if (appHash.equals(dataEnvelope.getDataBody().getDataChecksum()))
			checksumPass = true;
		return checksumPass;
	}
	
	// ========================================================================================================================
	// ========================================================================================================================
	// UPDATE
	// ========================================================================================================================
	// ========================================================================================================================

	public boolean updateDataBlock(String name,BlockTypeEnum blockType) {
		return setDataForUpdate(name,blockType);}

	private boolean setDataForUpdate(String name,BlockTypeEnum blockType) {		
		DataHeader dataHeader = new DataHeader();		
		dataHeader.setName(name);
		dataHeader.setBlockType(blockType);				
		dataHeaderServiceImpl.updateHeader(dataHeader);
		return true;
	}
	
	
	// ========================================================================================================================
	// ========================================================================================================================
	// GET
	// ========================================================================================================================
	// ========================================================================================================================

	
	  @Override 
	  public List<DataEnvelope> getDataBlock(BlockTypeEnum blockType) {
	  
		  List<DataEnvelope> dataEnvelopeList = retrive(blockType);
		  log.info("Data persisted successfully, data name: {}", blockType); 
		  return dataEnvelopeList; 
	  
	  }
	  
	  
	  private List<DataEnvelope> retrive(BlockTypeEnum blockType) {
	  
	  // TODO Auto-generated method stub List<DataEnvelope> dataEnvelope;
	  List<DataBodyEntity> dataBodyEntityList = getData(blockType);
	  
	  //Create a new DataEnveloping or add to the DataEnvelope list
	  List<DataEnvelope> dataEnvelopeList = new ArrayList<DataEnvelope>();
	  DataEnvelope dataEnvelope = new DataEnvelope();
	  for(DataBodyEntity dataBodyEntity : dataBodyEntityList) {
		  DataHeader dataHeader = new DataHeader();
		  DataBody dataBody = new DataBody();
		  dataBodyEntity.getDataHeaderEntity();
		  dataHeader.setBlockType(dataBodyEntity.getDataHeaderEntity().getBlocktype());
		  dataHeader.setName(dataBodyEntity.getDataHeaderEntity().getName());
		  dataEnvelope.setDataHeader(dataHeader);
		  dataBody.setDatabody(dataBodyEntity.getDataBody());
		  dataBody.setDataChecksum(dataBodyEntity.getDatachecksum());
		  dataEnvelope.setDataBody(dataBody);
		  dataEnvelopeList.add(dataEnvelope); 
	  }	  
	  
	  return dataEnvelopeList;	  
	  }
	  
	  private List<DataBodyEntity> getData(BlockTypeEnum blockType) {
	  List<DataBodyEntity> dataByBlockType =
	  dataBodyServiceImpl.getDataByBlockType(blockType);
	  return dataByBlockType; 
	  }

}
