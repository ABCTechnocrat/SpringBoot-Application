package com.db.dataplatform.techtest.client.component.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import com.db.dataplatform.techtest.client.RestTemplateConfiguration;
import com.db.dataplatform.techtest.client.component.Client;
import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Client code does not require any test coverage
 */

@Service
@Slf4j
@RequiredArgsConstructor
public class ClientImpl implements Client {

	@Autowired
	final RestTemplateConfiguration restTemplateConfiguration;
	RestTemplate restTemplate;
	public static final String URI_PUSHDATA = "http://localhost:8090/dataserver/pushdata";
	public static final UriTemplate URI_GETDATA = new UriTemplate("http://localhost:8090/dataserver/data/{blockType}");
	public static final UriTemplate URI_PATCHDATA = new UriTemplate(
			"http://localhost:8090/dataserver/update/{name}/{newBlockType}");

	public void pushData(DataEnvelope dataEnvelope) {

		log.info("Pushing data {} to {}", dataEnvelope.getDataHeader().getName());
		log.info("Pushing data {} to {}", dataEnvelope.getDataHeader().getBlockType(), URI_PUSHDATA);
		log.info("Pushing data {} to {}", dataEnvelope.getDataBody().getDatabody());

		if (dataEnvelope != null) {
			restTemplate = restTemplateConfiguration.createRestTemplate(null, null);
			Boolean responsePost = restTemplate.postForObject(URI_PUSHDATA, dataEnvelope, Boolean.class);
			log.info("String data {} to {}", responsePost);
		}
	}
	// ========================================================================================================================
	// ========================================================================================================================
	// UPDATE DATA PUT
	// ========================================================================================================================
	// ========================================================================================================================

	// envelop=new(header,detail)

	@Override
	public void updateData(String blockName, BlockTypeEnum newBlockType) {

		restTemplate = restTemplateConfiguration.createRestTemplate(null, null);
		boolean status = restTemplate.patchForObject(URI_PATCHDATA.toString(), null, Boolean.class, blockName,
				newBlockType);
		if (status)
			log.info("SUCCUSS - [Patch API attenpted] - Blockname-{} BlockType-{}", blockName, newBlockType);

	}

//========================================================================================================================
//========================================================================================================================
// FETCH DATA GET
//========================================================================================================================
//========================================================================================================================

	@SuppressWarnings("unchecked")
	@Override
	public List<DataEnvelope> getData(String strBlockType) {
		if (strBlockType != null) {
		}
		List<String> uriVariables = URI_GETDATA.getVariableNames();
		restTemplate = restTemplateConfiguration.createRestTemplate(null, null);
		String sort = URI_GETDATA.getVariableNames().get(0);
		List<DataEnvelope> listEnvelope = restTemplate.getForObject(URI_GETDATA.toString(), List.class, strBlockType);

		return listEnvelope;
	}

}
