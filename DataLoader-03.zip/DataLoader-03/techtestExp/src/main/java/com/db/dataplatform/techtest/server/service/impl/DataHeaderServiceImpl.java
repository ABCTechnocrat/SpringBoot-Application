package com.db.dataplatform.techtest.server.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.db.dataplatform.techtest.server.api.model.DataHeader;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;
import com.db.dataplatform.techtest.server.persistence.repository.DataHeaderRepository;

@Service
@RequiredArgsConstructor
public class DataHeaderServiceImpl implements com.db.dataplatform.techtest.server.service.DataHeaderService {

    private final DataHeaderRepository dataHeaderRepository;

    @Override
    public void saveHeader(DataHeaderEntity entity) {
        dataHeaderRepository.save(entity);
        
    }
   
        
        public void updateHeader(DataHeader dataHeader) {
        	String blockName = dataHeader.getName();
        	//String blocktype = dataHeader.getBlockType().name().toString();
            dataHeaderRepository.updateHeader(blockName, dataHeader.getBlockType());
            
     }
}
