package com.db.dataplatform.techtest.server.component.impl;

import java.io.IOException;

import com.db.dataplatform.techtest.server.component.ServerHadoop;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.List;
import java.util.Map;

	public class ServerHadoopImpl implements ServerHadoop{
		
		public void pushToHadoop() throws IOException {
			
			//The following configuratuin to be reconfigured
			//Clarification awaited
			
			URL url = new URL("http://localhost:8090/hadoopserver/pushbig?user.name=admin&op=add");
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			FileInputStream fin = new FileInputStream("/home/bijoyan/Documents/append.txt");
			BufferedReader br = new BufferedReader(new InputStreamReader(fin));			
			
			prepareConn(con);		
			pushToHDFS(con, br);

		}

		private void pushToHDFS(HttpURLConnection con, BufferedReader br) throws IOException {
			String line,content="";
			while((line=br.readLine()) != null){
				content+=line;
			}
			
			con.getOutputStream().write(content.getBytes());
			
			Map<String, List<String>> headers = con.getHeaderFields();
			for (String header : headers.keySet())
				System.out.println(header + ": "  + headers.get(header));
		}

		private void prepareConn(HttpURLConnection con) throws ProtocolException {
			con.setRequestMethod("POST");
			con.setDoOutput(true);
			con.setDoInput(true);
		}

	}



