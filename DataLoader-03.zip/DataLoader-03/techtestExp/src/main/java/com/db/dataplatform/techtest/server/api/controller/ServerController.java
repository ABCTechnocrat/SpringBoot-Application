
package com.db.dataplatform.techtest.server.api.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.util.UriTemplate;

import com.db.dataplatform.techtest.server.api.model.DataEnvelope;
import com.db.dataplatform.techtest.server.api.model.DataHeader;
import com.db.dataplatform.techtest.server.component.Server;
import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;

import javax.validation.Valid;
import javax.validation.constraints.AssertTrue;
import javax.xml.bind.DatatypeConverter;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Objects;

@Slf4j
@Controller
@RequestMapping("/dataserver")
@RequiredArgsConstructor
@Validated
public class ServerController {

	private final Server server;

	@PostMapping(value = "/pushdata", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Boolean> pushData(@Valid @RequestBody DataEnvelope dataEnvelope)
			throws IOException, NoSuchAlgorithmException {

		log.info("ServerConstroller  - DataHeaderName {} - BlockType { } - DataBody {}  - MD5 {}",
				dataEnvelope.getDataHeader().getName(), dataEnvelope.getDataHeader().getBlockType(),
				dataEnvelope.getDataBody().getDatabody(),dataEnvelope.getDataBody().getDataChecksum());
		
		boolean checksumPass=false;
		if(server.checksumeValidity(dataEnvelope)) 
			checksumPass = server.saveDataEnvelope(dataEnvelope);
		
		log.info("Data envelope persisted. Attribute name: {}", dataEnvelope.getDataHeader().getName());
		return ResponseEntity.ok(checksumPass);

	}

	

	// ========================================================================================================================
	// ========================================================================================================================
	// ========================================================================================================================
	// ========================================================================================================================
	// PUT
	// ========================================================================================================================
	// ========================================================================================================================
	// ========================================================================================================================

	@PatchMapping(value = "/update/{name}/{newBlockType}")
	public ResponseEntity<Boolean> updateHeader(@Valid @PathVariable String name, @PathVariable String newBlockType)
			throws IOException, NoSuchAlgorithmException {

		boolean status = server.updateDataBlock(name, BlockTypeEnum.valueOf(newBlockType));

		log.info("ServerConstroller.updateHeader()  - name {} - newBlockType { }", name, newBlockType);

		return ResponseEntity.ok(status);

	}
	// ========================================================================================================================
	// ========================================================================================================================
	// ========================================================================================================================
	// ========================================================================================================================
	// GET
	// ========================================================================================================================
	// ========================================================================================================================
	// ========================================================================================================================

	// List<com.db.dataplatform.techtest.server.api.model.DataEnvelope> data =
	// client.getData(BlockTypeEnum.BLOCKTYPEA.name())

	@GetMapping(value = "/data/{blocktype}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<DataEnvelope>> getBataBlocks(@Valid @PathVariable String blocktype)
			throws IOException, NoSuchAlgorithmException {

		log.info("ServerConstroller.updateHeader() blocktype - { }", blocktype);
		// System.out.println(blocktype);
		BlockTypeEnum blockTypeEnum = BlockTypeEnum.valueOf(blocktype);
		List<DataEnvelope> dataEnvelopList = server.getDataBlock(blockTypeEnum);

		log.info("ServerConstroller.updateHeader() blocktype - { }", blocktype);
		return new ResponseEntity<List<DataEnvelope>>(dataEnvelopList, HttpStatus.OK);

	}

}
