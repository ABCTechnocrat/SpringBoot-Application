package com.db.dataplatform.techtest.server.persistence.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.db.dataplatform.techtest.server.persistence.BlockTypeEnum;
import com.db.dataplatform.techtest.server.persistence.model.DataHeaderEntity;

@Repository
public interface DataHeaderRepository extends JpaRepository<DataHeaderEntity, Long> {
	
	@Modifying(clearAutomatically=true)
	@Transactional
	@Query("UPDATE DataHeaderEntity SET blocktype = :blocktype WHERE name = :name")
	void updateHeader(@Param("name") String name,@Param("blocktype") BlockTypeEnum blocktype) ;	

}
